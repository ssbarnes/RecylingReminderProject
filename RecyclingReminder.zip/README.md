# RecylingReminderProject
Create an app that lets garbage collectors tag a residence (on a map) as not separating recyclables. Helpful electronic reminder sent to homeowners on a given street, etc. Could include some historical views of repeat offenders.
